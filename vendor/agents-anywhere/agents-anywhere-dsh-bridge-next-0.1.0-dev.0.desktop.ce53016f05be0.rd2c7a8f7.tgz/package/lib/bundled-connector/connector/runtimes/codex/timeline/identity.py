from __future__ import annotations

import hashlib
from typing import Any


def timeline_item_id(
    raw: dict[str, Any],
    external_session_id: str,
    index: int,
) -> str:
    client_message_id = client_message_id_from_raw(raw)
    if client_message_id and _is_user_message(raw):
        return client_message_item_id(external_session_id, client_message_id)
    native_id = native_item_id(raw)
    if native_id is not None:
        return native_id
    return f"codex_{external_session_id}_{derived_key(raw, index)}"


def timeline_item_id_from_values(
    native_id: str | None,
    client_message_id: str | None,
    raw_type: str,
    role: str | None,
    turn_id: str | None,
    external_session_id: str,
    index: int,
) -> str:
    if client_message_id and is_user_message_values(raw_type=raw_type, role=role):
        return client_message_item_id(external_session_id, client_message_id)
    if native_id is not None:
        return native_id
    return (
        f"codex_{external_session_id}_"
        f"{derived_key_from_values(raw_type=raw_type, role=role, turn_id=turn_id, index=index)}"
    )


def client_message_item_id(
    external_session_id: str,
    client_message_id: str,
) -> str:
    identity = f"codex-client-message-v1\0{external_session_id}\0{client_message_id}"
    digest = hashlib.sha256(identity.encode("utf-8")).hexdigest()[:32]
    return f"codex_item_{digest}"


def turn_position_item_id(
    external_session_id: str,
    turn_id: str,
    position: int,
    lane: str = "assistant-message",
) -> str:
    identity = (
        f"codex-turn-item-v2\0{external_session_id}\0{turn_id}\0{lane}\0{position}"
    )
    digest = hashlib.sha256(identity.encode("utf-8")).hexdigest()[:32]
    return f"codex_item_{digest}"


def turn_item_lane(raw_type: str, role: str | None) -> str:
    """Return the position lane shared by live events and thread history."""

    if role == "user":
        return "user-message"
    if role == "assistant" and raw_type in {"agentMessage", "message"}:
        return "assistant-message"
    if raw_type == "reasoning":
        return "reasoning"
    if role == "tool":
        return f"tool:{raw_type}"
    if role == "system":
        return f"system:{raw_type}"
    return f"{role or 'item'}:{raw_type}"


def next_turn_lane_position(
    next_position_by_lane: dict[str, int],
    lane: str,
) -> int:
    """Assign a turn-local position without letting omitted lanes shift others."""

    if lane == "reasoning":
        return next_position_by_lane.get("assistant-message", 0)
    position = next_position_by_lane.get(lane, 0)
    next_position_by_lane[lane] = position + 1
    return position


def uses_turn_position_identity(raw_type: str, role: str | None) -> bool:
    return raw_type not in {
        "contextCompaction",
        "runtimeMessage",
        "turnEnd",
        "turnStart",
    }


def native_item_id(raw: dict[str, Any]) -> str | None:
    for key in ("id", "itemId", "item_id"):
        value = raw.get(key)
        if isinstance(value, str) and value:
            return value
    return None


def derived_key_from_values(
    raw_type: str,
    role: str | None,
    turn_id: str | None,
    index: int,
) -> str:
    if raw_type == "reasoning":
        return f"reasoning-{index}"
    parts = [
        raw_type,
        str(role or ""),
        str(turn_id or ""),
        str(index),
    ]
    stable = "-".join(_safe_component(part) for part in parts if part)
    return stable or f"item-{index}"


def derived_key(raw: dict[str, Any], index: int) -> str:
    explicit = explicit_derived_key(raw)
    if isinstance(explicit, str) and explicit:
        return explicit
    item_type = raw.get("type") or raw.get("kind") or "item"
    turn_id = _timeline_item_turn_id(raw)
    role = _timeline_item_role(raw)
    if isinstance(item_type, str) and item_type == "reasoning":
        return f"reasoning-{index}"
    parts = [
        str(item_type),
        str(role or ""),
        str(turn_id or ""),
        str(index),
    ]
    stable = "-".join(_safe_component(part) for part in parts if part)
    return stable or f"item-{index}"


def explicit_derived_key(raw: dict[str, Any]) -> str | None:
    value = raw.get("_derivedKey") or raw.get("derivedKey") or raw.get("derived_key")
    return value if isinstance(value, str) and value else None


def is_user_message_values(raw_type: str, role: str | None) -> bool:
    if role == "user":
        return True
    return raw_type in {"userMessage", "steeringUserMessage"}


def client_message_id_from_raw(raw: dict[str, Any]) -> str | None:
    value = (
        raw.get("_clientMessageId")
        or raw.get("clientMessageId")
        or raw.get("clientId")
        or raw.get("client_id")
    )
    return value if isinstance(value, str) and value else None


def _is_user_message(raw: dict[str, Any]) -> bool:
    if raw.get("role") == "user":
        return True
    return raw.get("type") in {"userMessage", "steeringUserMessage"}


def _timeline_item_turn_id(raw: dict[str, Any]) -> str | None:
    for key in ("turnId", "turn_id"):
        value = raw.get(key)
        if isinstance(value, str) and value:
            return value
    return None


def _timeline_item_role(raw: dict[str, Any]) -> str | None:
    value = raw.get("role")
    if isinstance(value, str) and value:
        return value
    item_type = raw.get("type")
    if item_type == "reasoning":
        return "system"
    if item_type in {"userMessage", "steeringUserMessage"}:
        return "user"
    if item_type == "agentMessage":
        return "assistant"
    if item_type == "commandExecution":
        return "tool"
    return None


def _safe_component(value: str) -> str:
    safe = "".join(
        char if char.isalnum() or char in {"_", "-"} else "_" for char in value
    )
    return safe[:96] or hashlib.sha256(value.encode()).hexdigest()[:24]
