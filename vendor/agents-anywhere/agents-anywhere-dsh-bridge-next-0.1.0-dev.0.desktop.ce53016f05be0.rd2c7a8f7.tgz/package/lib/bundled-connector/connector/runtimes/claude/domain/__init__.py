"""Claude runtime domain helpers."""
